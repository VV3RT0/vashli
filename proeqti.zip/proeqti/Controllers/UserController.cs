﻿using Microsoft.AspNetCore.Mvc;
using proeqti.DTOs;
using proeqti.model;
using Mapster;

namespace proeqti.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private static List<User> _users = new();
        private static int _idCounter = 1;

        [HttpPost]
        public IActionResult CreateUser([FromBody] CreateUserRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Email))
                throw new Exception("Email must not be empty.");

            var user = request.Adapt<User>();
            user.Id = _idCounter++;
            _users.Add(user);

            return Ok(user);
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded.");

            var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "Uploads");

            if (!Directory.Exists(uploadsFolder))
                Directory.CreateDirectory(uploadsFolder);

            var filePath = Path.Combine(uploadsFolder, file.FileName);

            using var stream = new FileStream(filePath, FileMode.Create);
            await file.CopyToAsync(stream);

            return Ok(new { FileName = file.FileName });
        }
    }
}
